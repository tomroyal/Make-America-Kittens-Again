# Make-America-Kittens-Again

This is the code for my Chrome extension:

https://chrome.google.com/webstore/detail/make-america-kittens-agai/klchnmggepghlcolikgaekpibclpmgcm

.. that replaces images of Donald Trump with kittens.

tomroyal.com